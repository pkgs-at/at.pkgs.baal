include('gdata-spreadsheet.js');

DataEntry = at.pkgs.Object.extend((
	function(instance) {
		instance = instance || this;
		this.parent.self(instance);
	}
), {
	update: function(value) {
		var key;

		for (key in value)
			this[key] = value[key];
	},
});

DataNode = at.pkgs.Object.extend((
	function(instance) {
		instance = instance || this;
		this.parent.self(instance);
		instance.data = new Object();
		instance.list = new Array();
	}
), {
	data: null,
	list: null,
	get: function(target, instance) {
		instance = instance || this;
		if (Object.isNumber(target)) {
			target = instance.list[target];
			return target ? instance.data[target] : void 0;
		}
		if (Object.isString(target)) {
			return instance.data[target];
		}
		if (Object.isArray(target)) {
			return target.map(function(value) {
				return instance.get(value);
			});
		}
		return Object.map(target, function(key, value) {
			return instance.get(value);
		});
	},
	set: function(name, value) {
		if (!this.data[name]) {
			this.data[name] = new DataEntry();
			this.list.add(name);
		}
		if (value) {
			this.data[name].update(value);
		}
	},
	size: function() {
		return this.list.length;
	},
	delegate: function(instance) {
		instance = instance || this;
		return function() {
			if (arguments.length <= 0) return instance;
			return instance.get.apply(instance, arguments);
		};
	},
}, {
	delegate: function() {
		return (new this()).delegate();
	},
});

DataContext = at.pkgs.Object.extend((
	function(instance) {
		instance = instance || this;
		this.parent.self(instance);
		instance.root = DataNode.delegate();
		instance.get('java');
		instance.get('Packages');
	}
), {
	root: null,
	get: function(qualified) {
		var node;

		node = this.root;
		qualified.split('.').each(function(name) {
			if (!node[name])
				node[name] = DataNode.delegate();
			node = node[name];
		});
		return node();
	},
	apply: function(value) {
		if (value === null) {
			return '';
		}
		if (!value.startsWith('@')) {
			return value;
		}
		with (this.root) {
			return eval('(' + value.substring(1) + ')');
		}
	},
	set: function(qualified, name, value, instance) {
		instance = instance || this;
		instance.get(qualified).set(name, Object.map(value, function(key, value) {
			return instance.apply(value);
		}));
	},
	list: function(prefix, node) {
		var list;
		var name;

		if (node === void 0) {
			prefix = '';
			node = this.root;
		}
		list = new Array();
		for (name in node) {
			if (!name.match(/^[A-Z]/)) continue;
			list.add(prefix + name);
			list.add(this.list(prefix + name + '.', node[name]));
		}
		return list;
	},
	data: function(instance) {
		var data;

		instance = instance || this;
		data = new Object();
		this.list().each(function(qualified) {
			var node;

			node = instance.get(qualified);
			if (node.size() <= 0) return;
			data[qualified] = new Object();
			data[qualified].values = node.data;
			data[qualified].keys = node.list;
		});
		return data;
	},
});

(function(unasigned) {
	var spreadsheet;
	var context;
	var worksheets;

	spreadsheet = Spreadsheet.open({
		application_id: parameters.get(
				'gdata.application_id'),
		user_id: parameters.get(
				'gdata.user_id'),
		password:  parameters.get(
				'gdata.password'),
		spreadsheet_id:  parameters.get(
				'gdata.spreadsheet_id'),
	});
	echo('working with spreadsheet: ' + spreadsheet.getTitle());
	context = new DataContext();
	worksheets = new Array();
	spreadsheet.retrieveAllWorksheets().each(function(worksheet) {
		var name;
		var node;

		name = worksheet.getTitle();
		if (name.startsWith('#')) return;
		worksheet.entity = model.Entity.get(name);
		if (!worksheet.entity) {
			echo('ignored worksheet for unknown entity: ' + name);
			return;
		}
		if (worksheet.entity.isAbstract()) {
			echo('ignored worksheet for abstract entity: ' + name);
			return;
		}
		worksheets.add(worksheet);
		node = context.get(name);
		worksheet.keys = worksheet.retrieveColumn(0).getValues(1);
		worksheet.keys.each(function(key) {
			if (!key || key.startsWith('#')) return;
			node.set(key);
		});
		echo('prepared worksheet: ' + name);
	});
	worksheets.each(function(worksheet) {
		var name;
		var node;
		var fields;

		name = worksheet.getTitle();
		if (name.startsWith('#')) return;
		if (!worksheet.entity || worksheet.entity.isAbstract()) return;
		echo('data generation from worksheet: ' + name);
		node = context.get(name);
		fields = worksheet.retrieveRow(0).getValues(1).map(function(name) {
			var field;

			if (!name || name.startsWith('#')) return null;
			name = name.valueOf();
			field = worksheet.entity.getAllFields().find(function(field) {
				return field.getName() == name;
			});
			if (!field) {
				echo('ignored field: ' + name);
				return null;
			}
			return field;
		});
		worksheet.keys.each(function(key, index) {
			var data;

			if (!key) return;
			if (!key || key.startsWith('#')) return;
			data = new Object();
			worksheet.entity.getAllFields().each(function(field) {
				data[field.getName()] = null;
			});
			worksheet.retrieveRow(index + 1).getValues(1).each(function (value, index) {
				var field;

				field = fields[index];
				if (!field) return;
				data[field.getName()] = value;
			});
			context.set(worksheet.entity.getName(), key, data);
		});
		echo('data generated: ' + node.size());
	});
	echo('data output into: ' + spreadsheet.getTitle() + '.json');
	write(
			spreadsheet.getTitle() + '.json',
			JSON.stringify(context.data(), unasigned, '    '),
			true);
})();
