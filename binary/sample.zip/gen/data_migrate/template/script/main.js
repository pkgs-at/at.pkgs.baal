include('gdata-spreadsheet.js');

FieldManager = at.pkgs.Object.extend((
	function(fields, instance) {
		instance = instance || this;
		this.parent.self(instance);
		instance.entries = new Array();
		instance.by_name = new Object();
		fields.each(function(field) {
			instance.append(field);
		});
	}
), { /* prototype */
	entries: null,
	by_name: null,
	append: function(field) {
		var entry;

		entry = new this.self.Entry(field);
		this.entries.add(entry);
		this.by_name[field.getName()] = entry;
	},
	update: function(index, name) {
		var entry;

		entry = this.by_name[name];
		if (!entry) return false;
		entry.index = index;
		entry.append = false;
		return true;
	},
	appendees: function(visitor) {
		this.entries.each(function(entry) {
			if (!entry.append) return;
			visitor.call(entry, entry.index, entry.field);
		});
	},
	index: function(index) {
		this.appendees(function() {
			this.index = index ++;
		});
		return index;
	},
}, { /* statics*/
	Entry: at.pkgs.Object.extend((
		function(field, instance) {
			instance = instance || this;
			this.parent.self(instance);
			instance.index = -1;
			instance.field = field;
			instance.append = true;
		}
	), { /* prototype */
		index: null,
		field: null,
		append: null,
	}),
});

(function(unasigned) {
	var spreadsheet;
	var worksheets;

	spreadsheet = Spreadsheet.open({
		application_id: parameters.get(
				'gdata.application_id'),
		user_id: parameters.get(
				'gdata.user_id'),
		password:  parameters.get(
				'gdata.password'),
		spreadsheet_id:  parameters.get(
				'gdata.spreadsheet_id'),
	});
	echo('working with spreadsheet: ' + spreadsheet.getTitle());
	worksheets = new Object();
	spreadsheet.retrieveAllWorksheets().each(function(worksheet) {
		var name;
		var entity;

		name = worksheet.getTitle();
		if (name.startsWith('#')) return;
		worksheets[name] = worksheet;
		entity = model.Entity.get(name);
		if (entity && !entity.isAbstract()) return;
		echo('unused worksheet into commentted out: ' + name);
		worksheet.setTitle('# ' + name);
		worksheet.save();
	});
	entities.each(function(entity) {
		var worksheet;
		var fields;
		var header;
		var unused;

		if (entity.isAbstract()) return;
		worksheet = worksheets[entity.getName()];
		if (!worksheet) {
			echo('append missing worksheet for: ' + entity.getName());
			worksheet = spreadsheet.insertWorksheet(entity.getName(), 20, 100);
		}
		echo('migrate entity into worksheet: ' + worksheet.getTitle());
		fields = new FieldManager(entity.getAllFields());
		header = worksheet.retrieveRow(0);
		unused = 1;
		header.getValues(1).each(function(value, index) {
			var entry;

			if (!value) {
				header.setValue(index + 1, '# ');
				return;
			}
			unused = index + 2;
			if (value.startsWith('#')) return;
			if (fields.update(index + 1, value)) return;
			echo('unused header into commentted out: ' + value);
			header.setValue(index + 1, '# ' + value);
		});
		header.save();
		unused = fields.index(unused);
		if (worksheet.getColumnCount() != unused) {
			worksheet.setColumnCount(unused);
			worksheet.save();
			header = worksheet.retrieveRow(0);
		}
		header.setValue(0, 'key \u2572 field');
		fields.appendees(function(index, field) {
			echo('append missing header for: ' + field.getName());
			header.setValue(index, field.getName());
		});
		header.save();
		
	});
})();
