/*
 * project type configuration
 */
