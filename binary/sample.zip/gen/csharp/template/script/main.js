include('types.csharp.js');
include('types.js');

/*
 * generate entities
 */
(function(_root_) {
	var document;
	var generated;
	var skeleton;

	document = template('EntityDocument.tmpl');
	generated = template('EntityGenerated.tmpl');
	skeleton = template('EntitySkeleton.tmpl');
	entities.each(function(entity) {
		var arguments;

		arguments = new Object();
		arguments.entity = entity;
		arguments.type = types.get(entity.getName());
		echo('!Q\xA1 generating entity: %s', entity.getName());
		document(
				arguments.type.path + '.md',
				arguments,
				true);
		generated(
				arguments.type.path + 'Generated.cs',
				arguments,
				true);
		if (!entity.isAbstract())
			skeleton(
					arguments.type.path + '.cs',
					arguments,
					false);
	});
})(this);

/*
 * generate services
 */
(function(_root_) {
	var document;
	var generated;
	var skeleton;

	document = template('ServiceDocument.tmpl');
	generated = template('ServiceGenerated.tmpl');
	skeleton = template('ServiceSkeleton.tmpl');
	services.each(function(service) {
		var arguments;

		arguments = new Object();
		arguments.service = service;
		arguments.type = types.get(service.getName());
		echo('!Q\xA1 generating service: %s', service.getName());
		document(
				arguments.type.path + '.md',
				arguments,
				true);
		generated(
				arguments.type.path + 'Generated.cs',
				arguments,
				true);
		skeleton(
				arguments.type.path + '.cs',
				arguments,
				false);
	});
})(this);
