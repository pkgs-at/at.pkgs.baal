/*
 * Google Data API Spreadsheet Client
 */
(function(root, unasigned) {
	var gdata;
	var Model;

	gdata = new JavaImporter(
			Packages.com.google.gdata.client.spreadsheet,
			Packages.com.google.gdata.data,
			Packages.com.google.gdata.data.batch,
			Packages.com.google.gdata.data.spreadsheet);
	Model = at.pkgs.Object.extend((
		function(entry, instance) {
			instance = instance || this;
			this.parent.self(instance);
			instance.entry = entry;
		}
	), { /* prototype */
		entry: null,
		getTitle: function() {
			return new String(this.entry.getTitle().getPlainText());
		},
		setTitle: function(value) {
			this.entry.setTitle(new gdata.PlainTextConstruct(value));
		},
		update: function() {
			this.entry = this.entry.getSelf();
		},
		save: function() {
			this.entry = this.entry.update();
		},
	}, { /* statics */
	});
	CellScope = at.pkgs.Object.extend((
		function(worksheet, feed, size, instance) {
			instance = instance || this;
			this.parent.self(instance);
			instance.worksheet = worksheet;
			instance.feed = feed;
			instance.size = size;
			instance.modified = new Array();
		}
	), { /* prototype */
		worksheet: null,
		feed: null,
		size: null,
		modified: null,
		getCount: function() {
			return this.feed.getEntries().size();
		},
		getColumnCount: function() {
			return this.size[0];
		},
		getRowCount: function() {
			return this.size[1];
		},
		indexOf: function(column, row) {
			if (row === unasigned) return column;
			else return row * this.getColumnCount() + column
		},
		getValue: function(column, row) {
			var index;
			var value;

			index = this.indexOf(column, row);
			value = this.feed.getEntries().get(index).getCell().getValue();
			return value == null ? null : new String(value);
		},
		setValue: function(column, row, value) {
			var index;

			if (value === unasigned) {
				index = column;
				value = row;
			}
			else {
				index = this.indexOf(column, row);
			}
			if (this.getValue(index) == value) return;
			this.feed.getEntries().get(index).changeInputValueLocal(value);
			this.modified.add(index);
		},
		getValues: function(offset, length) {
			var values;
			var index;

			index = offset || 0;
			limit = length ? (index + length) : this.getCount();
			values = new Array();
			for (; index < limit; index ++)
				values.add(this.getValue(index));
			return values;
		},
		save: function(instance) {
			var feed;
			var link;

			instance = instance || this;
			feed = new gdata.CellFeed();
			instance.modified = instance.modified.unique();
			if (instance.modified.length <= 0) return;
			instance.modified.each(function(index) {
				var entry;

				entry = instance.feed.getEntries().get(index);
				gdata.BatchUtils.setBatchId(
						entry,
						entry.getTitle().getPlainText());
				gdata.BatchUtils.setBatchOperationType(
						entry,
						gdata.BatchOperationType.UPDATE);
				feed.getEntries().add(entry);
			});
			instance.feed.getService().getRequestFactory().setHeader(
					'If-Match',
					'*');
			link = instance.feed.getLink(
					gdata.ILink.Rel.FEED_BATCH,
					gdata.ILink.Type.ATOM);
			feed = instance.feed.getService().batch(
					new java.net.URL(link.getHref()),
					feed);
			instance.feed.getService().getRequestFactory().setHeader(
					'If-Match',
					null);
			feed.getEntries().toArray().each(function(entry, index) {
				instance.feed.getEntries().set(
						instance.modified[index],
						entry);
			});
			instance.worksheet.update();
			instance.modified = new Array();
		},
	}, { /* statics */
	});
	Worksheet = Model.extend((
		function(entry, instance) {
			instance = instance || this;
			this.parent.self(entry, instance);
		}
	), { /* prototype */
		getColumnCount: function() {
			return this.entry.getColCount();
		},
		setColumnCount: function(value) {
			this.entry.setColCount(value);
		},
		getRowCount: function() {
			return this.entry.getRowCount();
		},
		setRowCount: function(value) {
			this.entry.setRowCount(value);
		},
		retrieveRange: function(origine, size) {
			var from;
			var to;
			var query;
			var feed;

			from = 'R' + (origine[1] + 1) + 'C' + (origine[0] + 1);
			to = 'R' + (origine[1] + size[1]) + 'C' + (origine[0] + size[0]);
			query = new gdata.CellQuery(this.entry.getCellFeedUrl());
			query.setRange(from + ':' + to);
			query.setReturnEmpty(true);
			feed = this.entry.getService().query(query, gdata.CellFeed);
			return new CellScope(this, feed, size);
		},
		retrieveColumn: function(column) {
			return this.retrieveRange([column, 0], [1, this.getRowCount()]);
		},
		retrieveRow: function(row) {
			return this.retrieveRange([0, row], [this.getColumnCount(), 1]);
		},
		retrieveEntire: function() {
			return this.retrieveRange([0, 0], [this.getColumnCount(), this.getRowCount()]);
		},
	}, { /* statics */
	});
	Spreadsheet = Model.extend((
		function(entry, instance) {
			instance = instance || this;
			this.parent.self(entry, instance);
		}
	), { /* prototype */
		retrieveAllWorksheets: function(instance) {
			var models;

			models = new Array();
			this.entry.getWorksheets().toArray().each(function(entry) {
				models.add(new Worksheet(entry));
			});
			return models;
		},
		insertWorksheet: function(title, columnCount, rowCount) {
			var entry;

			entry = new gdata.WorksheetEntry(rowCount, columnCount);
			entry.setTitle(new gdata.PlainTextConstruct(title));
			entry = this.entry.getService().insert(
					this.entry.getWorksheetFeedUrl(),
					entry);
			return new Worksheet(entry);
		},
	}, { /* statics */
		spreadsheet_path: 'http://spreadsheets.google.com/feeds/spreadsheets/',
		open: function(config) {
			var service;
			var url;

			service = new gdata.SpreadsheetService(config.application_id);
			service.setUserCredentials(config.user_id, config.password);
			url = new java.net.URL(
					this.spreadsheet_path + config.spreadsheet_id);
			return new Spreadsheet(service.getEntry(url, gdata.SpreadsheetEntry));
		},
	});
})(this);
